/*==============================================================*/
/* Nom de SGBD :  MySQL 5.0                                     */
/* Date de cr�ation :  06/05/2019 09:00:48                      */
/*==============================================================*/


drop table if exists ADMIN;

drop table if exists POSTS;

/*==============================================================*/
/* Table : ADMIN                                                */
/*==============================================================*/
create table ADMIN
(
   ID                   int not null auto_increment,
   LOGIN                varchar(100) not null,
   MDP                  varchar(1000) not null,
   primary key (ID)
);

/*==============================================================*/
/* Table : POSTS                                                */
/*==============================================================*/
create table POSTS
(
   IDPOST               int not null auto_increment,
   DATE                 datetime not null,
   TITRE                varchar(200) not null,
   DETAILS              varchar(1000) not null,
   STATUS               int not null,
   VALIDE               int not null,
   IMAGE                varchar(200) not null,
   primary key (IDPOST)
);

